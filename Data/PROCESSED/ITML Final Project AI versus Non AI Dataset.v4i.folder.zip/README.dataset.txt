# ITML Final Project AI versus Non AI Dataset > 2022-12-12 12:38pm
https://universe.roboflow.com/itml-project/itml-final-project-ai-versus-non-ai-dataset

Provided by a Roboflow user
License: CC BY 4.0

